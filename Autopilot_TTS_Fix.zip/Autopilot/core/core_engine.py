"""Core engine: the application orchestrator that wires every module.

RULE 1 (agents instructions): modules never import each other. This file
is THE documented seam — the core layer imports ``modules/*``, creates
one instance per registry entry in ``config/modules_config.json``
priority order, and runs the v1 documentary pipeline end-to-end:

    license -> parse/persist -> channel profile -> voice profiles ->
    keywords -> quality gate (+ autofix) -> images -> TTS ->
    SFX -> final mix -> SRT -> intro/outro -> timeline ->
    per-scene renders (animation + grade) -> join+audio mux ->
    subtitle burn -> verify -> thumbnails -> drive upload (optional,
    self-skips when disabled/offline) -> project completion

Stage criticality mirrors the registry ``required`` flags plus two
pipeline-level additions documented below (TTS and audio: a video
without narration is not a renderable documentary, even though the
modules themselves may be disabled). Optional-stage failures degrade
to warnings so one bad SFX never kills a 20-minute render.

Coarse state is tracked through core/render_state_machine.py
(LOADING -> VALIDATING -> GENERATING -> PROCESSING -> RENDERING ->
EXPORTING -> COMPLETE); per-render crash recovery stays inside
export_engine's render_progress table - this orchestrator does not
duplicate it (RULE 1's "duplicate tiny logic" ban applies to state too).

PLUGINS (D.8): user-provided Python files in ``plugins/`` (registry:
``config/plugins_config.json``) are loaded from their file path -
importlib.util.spec_from_file_location, so they work identically in dev
and in the frozen onedir exe where ``plugins/`` sits beside the EXE.
Each plugin defines ONE BaseModule subclass with PLUGIN_API = 1 and a
``run(context) -> dict`` method. Plugins are NOT pipeline stages (the
v1 stage order stays fixed and honest); they are standalone commands
via ``main.py plugin <name>`` or CoreEngine.run_plugin(). Loading is as
forgiving as module loading (RULE 7): broken files are recorded in the
report, never raised.
"""

from __future__ import annotations

import importlib
import importlib.util
import inspect
import json
import time
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from core.correlation import CorrelationContext
from core.render_state_machine import RenderState, RenderStateMachine
from core.service_container import BaseModule, ServiceContainer
from core.time_helper import utc_now_str

MODULE_NAME = "core_engine"

# The batch_engine processor seam (D.1): batch_engine takes a callable;
# core_engine supplies it (batch_engine itself imports nothing).

_PAUSE_BETWEEN_LINES = 0.25  # matches audio_processor narration default

# stage name -> (module name, required) for the fixed v1 pipeline order.
# "required" drives abort-vs-warn; module registry "required" drives
# skip-on-disabled. Two deliberate differences from the registry:
#   tts/audio are registry-optional but pipeline-required (no narration
#   or mixed audio -> nothing worth rendering).
_STAGE_MODULES: List[tuple] = [
    ("license", "core.license_manager", True),
    ("parse", "file_parser", True),
    ("channel_profile", "channel_profile_manager", False),
    ("voice_profiles", "voice_profile_manager", False),
    ("keywords", "keyword_analyzer", False),
    ("quality_gate", "quality_checker", False),
    ("images", "image_processor", True),
    ("tts", "tts_engine_manager", True),
    ("sfx", "sfx_engine", False),
    ("audio_mix", "audio_processor", True),
    ("subtitles", "subtitle_engine", False),
    ("intro_outro", "intro_outro_engine", False),
    ("timeline", "timeline_engine", True),
    ("export", "export_engine", True),
    ("burn_subtitles", "subtitle_engine", False),
    ("verify", "export_engine", True),
    ("thumbnails", "thumbnail_generator", False),
    ("drive_upload", "drive_upload_engine", False),
]
_LICENSE_ALLOWED_STATUSES = ("active", "trial")

# D.8 plugin contract: plugins declare PLUGIN_API with this integer.
PLUGIN_API_VERSION = 1


def _ms(started: float) -> float:
    """Elapsed milliseconds."""
    return round((time.perf_counter() - started) * 1000.0, 3)


def _pick_path(data: Dict[str, Any], *keys: str) -> Optional[str]:
    """First non-empty string value among candidate response keys."""
    for key in keys:
        value = data.get(key)
        if value and isinstance(value, str):
            return value
    return None


class CoreEngine(BaseModule):
    """Create and orchestrate all pipeline module instances."""

    def __init__(
        self,
        container: ServiceContainer,
        module_loader: Optional[Callable[[str], Optional[Any]]] = None,
        auto_load: bool = True,
    ) -> None:
        """Initialize the orchestrator and (optionally) load modules.

        ``module_loader`` is the test/DI seam: when supplied it maps a
        registry module name to an instance, bypassing importlib.
        """
        super().__init__(container, MODULE_NAME)
        self.container = container  # BaseModule keeps services, not this
        self._assets_col_cache: Optional[str] = None  # PRAGMA-resolved
        self._module_loader = module_loader
        self._modules: Dict[str, Any] = {}
        self._load_report: Dict[str, Dict[str, Any]] = {}
        self._plugins: Dict[str, Any] = {}
        self._plugin_report: Dict[str, Dict[str, Any]] = {}
        self._state_machine = RenderStateMachine(self.event_bus)
        self._running = False
        self._cancel_requested = False
        self._last_pipeline: Optional[Dict[str, Any]] = None
        if auto_load:
            self.load_modules()
            self.load_plugins()

    def is_optional_module(self) -> bool:
        """The orchestrator is required infrastructure."""
        return False

    # ------------------------------------------------------------------
    # Module loading (registry-driven; importlib lives ONLY here)
    # ------------------------------------------------------------------
    def _registry(self) -> List[Dict[str, Any]]:
        try:
            data = self.config.get_config("modules_config") or {}
        except (OSError, ValueError, KeyError) as exc:
            self.log.error("modules_config unreadable: %s", exc)
            return []
        entries = data.get("modules") if isinstance(data, dict) else None
        if not isinstance(entries, list):
            return []
        return sorted(entries, key=lambda e: int(e.get("priority") or 99))

    @staticmethod
    def _discover_class(mod: Any, module_name: str) -> Optional[type]:
        """Find the BaseModule subclass defined in the loaded module."""
        for _, obj in inspect.getmembers(mod, inspect.isclass):
            if (
                issubclass(obj, BaseModule)
                and obj is not BaseModule
                and obj.__module__ == mod.__name__
            ):
                return obj
        return None

    def load_modules(self) -> Dict[str, Any]:
        """Instantiate every enabled registry module in priority order.

        Import/instantiation failures are recorded per module and never
        raised: the pipeline decides at stage time whether a missing
        module is fatal (required) or a warning (optional) - RULE 7.
        """
        started = time.perf_counter()
        self._load_report = {}
        loaded = 0
        for entry in self._registry():
            name = str(entry.get("name") or "")
            if not name:
                continue
            report = {
                "enabled": bool(entry.get("enabled", True)),
                "required": bool(entry.get("required", False)),
                "priority": int(entry.get("priority") or 99),
                "loaded": False,
                "error": None,
            }
            if not report["enabled"]:
                report["error"] = "disabled in registry"
                self._load_report[name] = report
                continue
            try:
                if self._module_loader is not None:
                    instance = self._module_loader(name)
                    if instance is None:
                        raise ImportError(f"module_loader returned None: {name}")
                else:
                    mod = importlib.import_module(f"modules.{name}")
                    cls = self._discover_class(mod, name)
                    if cls is None:
                        raise ImportError(f"no BaseModule subclass in {name}")
                    instance = cls(self.container)
            except Exception as exc:  # noqa: BLE001 - isolate module faults
                self.log.error("module load failed %s: %s", name, exc)
                report["error"] = str(exc)
                self._load_report[name] = report
                continue
            self._modules[name] = instance
            report["loaded"] = True
            loaded += 1
            self._load_report[name] = report
        return self.make_response(
            True,
            {
                "loaded": loaded,
                "total_registry": len(self._load_report),
                "modules": self._load_report,
            },
            duration_ms=_ms(started),
        )

    def module(self, name: str) -> Optional[Any]:
        """Return a loaded module instance (or None)."""
        return self._modules.get(name)

    @staticmethod
    def stage_names() -> List[str]:
        """Ordered pipeline stage names (UI progress displays, docs).

        Public additive API (D.4): derived from the module-level
        _STAGE_MODULES table so the UI can never drift from the real
        stage plan.
        """
        return [name for name, _module, _required in _STAGE_MODULES]

    def get_module_status(self) -> Dict[str, Any]:
        """Load report for every registry entry."""
        started = time.perf_counter()
        return self.make_response(
            True,
            {
                "loaded_modules": sorted(self._modules),
                "report": self._load_report,
            },
            duration_ms=_ms(started),
        )

    # ------------------------------------------------------------------
    # Plugin interface (D.8): user plugins from plugins/ + registry JSON
    # ------------------------------------------------------------------
    def _plugins_folder(self) -> Path:
        """plugins/ beside the project root (parent of config folder)."""
        folder = getattr(self.config, "config_folder", None)
        try:
            if folder:
                return Path(str(folder)).resolve().parent / "plugins"
        except (TypeError, ValueError, OSError):
            pass
        return Path.cwd() / "plugins"

    def _plugin_registry(self) -> List[Dict[str, Any]]:
        try:
            data = self.config.get_config("plugins_config") or {}
        except (OSError, ValueError, KeyError) as exc:
            self.log.error("plugins_config unreadable: %s", exc)
            return []
        entries = data.get("plugins") if isinstance(data, dict) else None
        if not isinstance(entries, list):
            return []
        clean = []
        for entry in entries:
            if isinstance(entry, dict) and entry.get("name"):
                clean.append(entry)
        return sorted(clean, key=lambda e: str(e.get("name")))

    def load_plugins(self) -> Dict[str, Any]:
        """Instantiate every enabled plugin (file-path import).

        Mirrors load_modules' forgiveness contract: every failure is
        recorded in the report (RULE 7), never raised. Plugins load from
        their file path, so no package semantics are needed - this works
        for user files dropped beside the frozen exe too.
        """
        started = time.perf_counter()
        self._plugin_report = {}
        loaded = 0
        folder = self._plugins_folder()
        for entry in self._plugin_registry():
            name = str(entry.get("name"))
            report = {
                "enabled": bool(entry.get("enabled", True)),
                "loaded": False,
                "error": None,
            }
            if not report["enabled"]:
                report["error"] = "disabled in registry"
                self._plugin_report[name] = report
                continue
            path = folder / f"{name}.py"
            if not path.is_file():
                report["error"] = f"plugin file not found: {path}"
                self._plugin_report[name] = report
                continue  # RULE 7: record, never raise
            try:
                spec = importlib.util.spec_from_file_location(
                    f"autopilot_plugin_{name}", path
                )
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                cls = self._discover_class(mod, name)
                if cls is None:
                    raise ImportError(f"no BaseModule subclass in {name}")
                api = getattr(mod, "PLUGIN_API", None)
                if api != PLUGIN_API_VERSION:
                    raise ImportError(
                        f"plugin API {api!r} unsupported"
                        f" (need {PLUGIN_API_VERSION})"
                    )
                try:
                    instance = cls(self.container)
                except TypeError as exc:
                    # Minimal plugins skip __init__ boilerplate entirely;
                    # BaseModule then needs the module_name argument.
                    if "module_name" not in str(exc):
                        raise
                    instance = cls(self.container, name)
            except Exception as exc:  # noqa: BLE001 - isolate plugin faults
                self.log.error("plugin load failed %s: %s", name, exc)
                report["error"] = str(exc)
                self._plugin_report[name] = report
                continue
            self._plugins[name] = instance
            report["loaded"] = True
            loaded += 1
            self._plugin_report[name] = report
        return self.make_response(
            True,
            {"loaded": loaded, "plugins": self._plugin_report},
            duration_ms=_ms(started),
        )

    def plugin(self, name: str) -> Optional[Any]:
        """Return a loaded plugin instance (or None)."""
        return self._plugins.get(name)

    def plugin_names(self) -> List[str]:
        """Sorted names of successfully loaded plugins."""
        return sorted(self._plugins)

    def get_plugin_status(self) -> Dict[str, Any]:
        """Load report for every plugins_config entry."""
        started = time.perf_counter()
        return self.make_response(
            True,
            {
                "loaded_plugins": self.plugin_names(),
                "report": self._plugin_report,
            },
            duration_ms=_ms(started),
        )

    def run_plugin(
        self, name: str, context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Run one plugin's run(context); normalize to a response dict.

        Plugin crashes are isolated into failed responses exactly like
        stage crashes; plugin.started/completed/failed ride the bus.
        """
        started = time.perf_counter()
        instance = self._plugins.get(name)
        if instance is None:
            return self.make_response(
                False, error=f"plugin not loaded: {name}"
            )
        self.event_bus.publish("plugin.started", {"plugin": name})
        try:
            result = instance.run(dict(context or {}))
        except Exception as exc:  # noqa: BLE001 - plugin fault isolation
            self.log.exception("plugin %s crashed", name)
            self.event_bus.publish(
                "plugin.failed", {"plugin": name, "error": str(exc)}
            )
            return self.make_response(
                False, error=f"plugin crash: {exc}",
                duration_ms=_ms(started),
            )
        if not isinstance(result, dict):
            result = {"success": True, "data": {"result": result}}
        data = result.get("data")
        if not isinstance(data, dict):
            data = {
                k: v
                for k, v in result.items()
                if k
                not in (
                    "success", "data", "error", "warnings",
                    "module", "timestamp", "duration_ms",
                )
            }
        success = bool(result.get("success", True))
        response = self.make_response(
            success,
            data=data,
            error=result.get("error"),
            warnings=list(result.get("warnings") or []),
            duration_ms=_ms(started),
        )
        if success:
            self.event_bus.publish("plugin.completed", {"plugin": name})
        else:
            self.event_bus.publish(
                "plugin.failed",
                {"plugin": name, "error": response.get("error")},
            )
        return response

    # ------------------------------------------------------------------
    # Batch wiring (batch_engine RULE 1 seam)
    # ------------------------------------------------------------------
    def make_batch_processor(self) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
        """Closure for batch_engine.process_queue(processor=...).

        The batch queue row provides project_id (preferred) or a folder;
        a folder-only queue item fails honestly (parsing project folders
        is the UI/import flow's job, not the render queue's).
        """

        def _processor(item: Dict[str, Any]) -> Dict[str, Any]:
            project_id = item.get("project_id")
            if not project_id:
                return {
                    "success": False,
                    "data": {},
                    "error": "batch item has no project_id",
                }
            channel_profile = item.get("channel_profile_id")
            result = self.run_project_pipeline(
                str(project_id),
                channel_profile_id=channel_profile or None,
            )
            return dict(result)

        return _processor

    # ------------------------------------------------------------------
    # Public pipeline entry points
    # ------------------------------------------------------------------
    def run_script_pipeline(
        self,
        script_path: Any,
        project_folder: Any,
        title: Optional[str] = None,
        images_folder: Optional[Any] = None,
        export_preset: Optional[str] = None,
        channel_profile_id: Optional[str] = None,
        skip_stages: tuple = (),
        enforce_license: bool = True,
        quality_gate: bool = False,
    ) -> Dict[str, Any]:
        """End-to-end run: parse a script file, persist, then render.

        ``quality_gate`` False (default) runs the 12 checks as advisory
        warnings; True aborts the pipeline on unresolved critical/error
        issues (use for unattended batch renders).
        """
        if self._running:
            return self.make_response(
                False, error="a pipeline run is already in progress"
            )
        ctx: Dict[str, Any] = {
            "script_path": str(script_path),
            "project_folder": str(project_folder),
            "project_title": title,
            "images_folder": str(images_folder) if images_folder else None,
            "export_preset": export_preset,
            "channel_profile_id": channel_profile_id,
            "parsed_data": None,
            "project_id": None,
        }
        return self._run(ctx, skip_stages, enforce_license, quality_gate)

    def run_project_pipeline(
        self,
        project_id: str,
        export_preset: Optional[str] = None,
        channel_profile_id: Optional[str] = None,
        skip_stages: tuple = (),
        enforce_license: bool = True,
        quality_gate: bool = False,
    ) -> Dict[str, Any]:
        """Render a project that already has scenes/dialogue in the DB."""
        if self._running:
            return self.make_response(
                False, error="a pipeline run is already in progress"
            )
        project = self.db.db.fetch_one(
            "SELECT * FROM projects WHERE id = ?", (str(project_id),)
        )
        if project is None:
            return self.make_response(
                False, error=f"Project not found: {project_id}"
            )
        ctx = {
            "script_path": None,
            "project_folder": str(project.get("project_folder_path") or "."),
            "project_title": project.get("title"),
            "images_folder": None,
            "export_preset": export_preset or project.get("export_preset"),
            "channel_profile_id": channel_profile_id
            or project.get("channel_profile_id"),
            "parsed_data": None,
            "project_id": str(project_id),
        }
        return self._run(ctx, skip_stages, enforce_license, quality_gate)

    def cancel_pipeline(self) -> Dict[str, Any]:
        """Best-effort cancel: honored between scenes/lines, not mid-FFmpeg."""
        started = time.perf_counter()
        self._cancel_requested = True
        return self.make_response(
            True, {"cancel_requested": True}, duration_ms=_ms(started)
        )

    def get_state(self) -> Dict[str, Any]:
        """Coarse render-machine state + last pipeline summary."""
        started = time.perf_counter()
        return self.make_response(
            True,
            {
                "render_state": self._state_machine.state_name,
                "pipeline_running": self._running,
                "cancel_requested": self._cancel_requested,
                "last_pipeline": self._last_pipeline,
            },
            duration_ms=_ms(started),
        )

    # ------------------------------------------------------------------
    # Pipeline driver
    # ------------------------------------------------------------------
    def _run(
        self,
        ctx: Dict[str, Any],
        skip_stages: tuple,
        enforce_license: bool,
        quality_gate: bool,
    ) -> Dict[str, Any]:
        started = time.perf_counter()
        if not self._enabled:
            return self.make_response(False, error="core_engine is disabled")
        if self._running:
            return self.make_response(
                False, error="a pipeline run is already in progress"
            )
        self._running = True
        self._cancel_requested = False
        self._state_machine.reset_to_idle()
        self._transition(RenderState.LOADING, "pipeline start")
        correlation = CorrelationContext.new_id()
        CorrelationContext.set(correlation)
        stages: List[Dict[str, Any]] = []
        ctx["warnings"] = []
        ctx["skip_stages"] = set(skip_stages or ())
        ctx["quality_gate"] = bool(quality_gate)
        ctx["enforce_license"] = bool(enforce_license)
        ctx["correlation_id"] = correlation
        self.event_bus.publish(
            "pipeline.started",
            {"project_id": ctx.get("project_id"), "correlation_id": correlation},
        )
        failed_stage: Optional[str] = None
        aborted_reason: Optional[str] = None
        try:
            for stage_name, _module, _required in _STAGE_MODULES:
                result = self._execute_stage(stage_name, ctx)
                stages.append(result)
                if result["status"] == "failed":
                    failed_stage = stage_name
                    aborted_reason = (
                        f"pipeline aborted at stage '{stage_name}':"
                        f" {result.get('error')}"
                    )
                    self._transition(RenderState.FAILED, f"stage {stage_name}")
                    break
                if result["status"] == "cancelled":
                    failed_stage = stage_name
                    aborted_reason = "pipeline cancelled by user"
                    self._transition(RenderState.CANCELLED, "user request")
                    break
            if failed_stage is None:
                self._finalize_success(ctx)
        finally:
            self._running = False
            CorrelationContext.clear()

        summary = {
            "project_id": ctx.get("project_id"),
            "correlation_id": correlation,
            "stages": stages,
            "failed_stage": failed_stage,
            "output_file_path": ctx.get("final_output"),
            "warnings": ctx["warnings"],
            "render_state": self._state_machine.state_name,
        }
        self._last_pipeline = {
            "project_id": ctx.get("project_id"),
            "failed_stage": failed_stage,
            "output_file_path": ctx.get("final_output"),
            "timestamp": utc_now_str(),
        }
        if failed_stage:
            self.event_bus.publish(
                "pipeline.failed",
                {"project_id": ctx.get("project_id"), "stage": failed_stage},
            )
            return self.make_response(
                False,
                data=summary,
                error=aborted_reason
                or f"pipeline aborted at stage '{failed_stage}'",
                warnings=ctx["warnings"],
                duration_ms=_ms(started),
            )
        self.event_bus.publish(
            "pipeline.completed",
            {
                "project_id": ctx.get("project_id"),
                "output_file_path": ctx.get("final_output"),
            },
        )
        return self.make_response(
            True,
            data=summary,
            warnings=ctx["warnings"],
            duration_ms=_ms(started),
        )

    _LEGAL_CHAIN = (
        RenderState.LOADING,
        RenderState.VALIDATING,
        RenderState.GENERATING,
        RenderState.PROCESSING,
        RenderState.RENDERING,
        RenderState.EXPORTING,
        RenderState.COMPLETE,
    )

    def _transition(self, state: RenderState, reason: str) -> None:
        """Transition the render machine, walking the legal chain on skips.

        Skipped stages may leave the machine several states behind the
        next real stage (e.g. GENERATING -> RENDERING when subtitles are
        skipped). The chain hop keeps the machine honest without
        spamming illegal-transition warnings.
        """
        if self._state_machine.state is state:
            return
        if self._state_machine.transition_to(state, reason):
            return
        chain = list(self._LEGAL_CHAIN)
        if state not in chain or self._state_machine.state not in chain:
            self.log.warning(
                "illegal render transition -> %s (%s)", state.name, reason
            )
            return
        current_idx = chain.index(self._state_machine.state)
        target_idx = chain.index(state)
        for hop in chain[current_idx + 1 : target_idx + 1]:
            self._state_machine.transition_to(hop, f"en route to {state.name}")

    def _execute_stage(
        self, stage_name: str, ctx: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Run one stage; uniform result for the stages list."""
        started = time.perf_counter()
        module_name, required = next(
            (m, r) for s, m, r in _STAGE_MODULES if s == stage_name
        )
        if stage_name in ctx["skip_stages"]:
            self.event_bus.publish(
                "pipeline.stage_skipped",
                {"stage": stage_name, "reason": "skip_stages"},
            )
            return {
                "stage": stage_name, "status": "skipped",
                "reason": "skip_stages", "duration_ms": _ms(started),
            }
        if stage_name == "license" and not ctx.get("enforce_license", True):
            return {
                "stage": stage_name, "status": "skipped",
                "reason": "license enforcement off", "duration_ms": _ms(started),
            }
        instance = None
        if stage_name == "license":
            instance = self._license_instance(ctx)
        else:
            instance = self._modules.get(module_name)
        if instance is None:
            if stage_name == "license":
                msg = "license manager unavailable; continuing without gate"
                ctx["warnings"].append(msg)
                self.log.warning(msg)
                return {
                    "stage": stage_name, "status": "warning", "error": msg,
                    "duration_ms": _ms(started),
                }
            msg = f"module '{module_name}' not loaded"
            if required:
                self.event_bus.publish(
                    "pipeline.stage_failed", {"stage": stage_name, "error": msg}
                )
                return {
                    "stage": stage_name, "status": "failed", "error": msg,
                    "duration_ms": _ms(started),
                }
            ctx["warnings"].append(f"{stage_name} skipped: {msg}")
            return {
                "stage": stage_name, "status": "skipped", "reason": msg,
                "duration_ms": _ms(started),
            }
        enabled = getattr(instance, "enabled", True)
        if not enabled:
            msg = f"module '{module_name}' disabled"
            if required:
                return {
                    "stage": stage_name, "status": "failed", "error": msg,
                    "duration_ms": _ms(started),
                }
            ctx["warnings"].append(f"{stage_name} skipped: {msg}")
            return {
                "stage": stage_name, "status": "skipped", "reason": msg,
                "duration_ms": _ms(started),
            }

        self.event_bus.publish(
            "pipeline.stage_started",
            {"stage": stage_name, "project_id": ctx.get("project_id")},
        )
        handler = getattr(self, f"_stage_{stage_name}")
        try:
            outcome = handler(instance, ctx)
        except Exception as exc:  # noqa: BLE001 - stage isolation
            self.log.exception("stage %s crashed", stage_name)
            outcome = {"success": False, "error": f"stage crash: {exc}"}
        outcome = dict(outcome or {})
        ok = bool(outcome.get("success"))
        for warn in outcome.get("warnings") or []:
            ctx["warnings"].append(f"[{stage_name}] {warn}")
        if outcome.get("cancelled"):
            return {
                "stage": stage_name, "status": "cancelled",
                "duration_ms": _ms(started),
            }
        if ok:
            skipped_reason = None
            if isinstance(outcome.get("data"), dict):
                skipped_reason = outcome["data"].get("skipped")
            if skipped_reason:  # module-level self-skip (D.7): honest
                self.event_bus.publish(  # "skipped", not "completed"
                    "pipeline.stage_skipped",
                    {"stage": stage_name, "reason": str(skipped_reason)},
                )
                return {
                    "stage": stage_name, "status": "skipped",
                    "reason": str(skipped_reason),
                    "duration_ms": _ms(started),
                }
            self.event_bus.publish(
                "pipeline.stage_completed",
                {"stage": stage_name, "project_id": ctx.get("project_id")},
            )
            return {
                "stage": stage_name, "status": "completed",
                "data_keys": sorted((outcome.get("data") or {}).keys())
                if isinstance(outcome.get("data"), dict)
                else [],
                "duration_ms": _ms(started),
            }
        error = str(outcome.get("error") or "unknown stage failure")
        if outcome.get("hard_fail"):
            required = True  # stage escalates itself (hard quality gate)
        if required:
            self.event_bus.publish(
                "pipeline.stage_failed", {"stage": stage_name, "error": error}
            )
            return {
                "stage": stage_name, "status": "failed", "error": error,
                "duration_ms": _ms(started),
            }
        ctx["warnings"].append(f"{stage_name} failed (optional): {error}")
        return {
            "stage": stage_name, "status": "warning", "error": error,
            "duration_ms": _ms(started),
        }

    # ------------------------------------------------------------------
    # Stage 0: license
    # ------------------------------------------------------------------
    def _license_instance(self, ctx: Dict[str, Any]) -> Optional[Any]:
        """LicenseManager lives in core/, not the module registry."""
        if ctx.get("enforce_license", True):
            try:
                from core.license_manager import LicenseManager

                return LicenseManager(self.container)
            except Exception as exc:  # noqa: BLE001
                self.log.error("license manager unavailable: %s", exc)
                return None
        return None

    def _stage_license(self, manager: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        checked = manager.check_license()
        data = checked.get("data") or {}
        status = str(data.get("status") or "invalid")
        ctx["license_status"] = status
        if status in _LICENSE_ALLOWED_STATUSES:
            return {"success": True, "data": {"status": status}}
        return {
            "success": False,
            "error": f"license status '{status}' blocks rendering",
            "data": {"status": status, "days_remaining": data.get("days_remaining")},
        }

    # ------------------------------------------------------------------
    # Stage 1: parse + persist (script flow only)
    # ------------------------------------------------------------------
    def _stage_parse(self, parser: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        if ctx.get("project_id"):
            return {"success": True, "data": {"reused_project": True}}
        self._transition(RenderState.LOADING, "parse script")
        parsed = parser.parse_script(ctx["script_path"])
        if not parsed.get("success"):
            return parsed
        data = parsed.get("data") or {}
        ctx["parsed_data"] = data
        project_id = self.db.new_id()
        settings = data.get("project_settings") or {}
        folder = Path(str(ctx["project_folder"]))
        folder.mkdir(parents=True, exist_ok=True)
        title = ctx.get("project_title") or settings.get("title") or "Untitled"
        created = self.db.create_project(
            {
                "id": project_id,
                "title": title,
                "project_folder_path": str(folder),
                "genre": settings.get("genre") or "dark_history",
            }
        )
        if not created:
            return {"success": False, "error": "create_project failed"}
        ctx["project_id"] = project_id
        self._persist_scenes_and_lines(project_id, data, ctx)
        return {
            "success": True,
            "data": {"project_id": project_id,
                     "scenes": len(data.get("scenes") or [])},
        }

    def _persist_scenes_and_lines(
        self, project_id: str, data: Dict[str, Any], ctx: Dict[str, Any]
    ) -> None:
        images_root = ctx.get("images_folder")
        for index, scene in enumerate(data.get("scenes") or [], start=1):
            scene_id = self.db.new_id()
            image_name = str(scene.get("image") or "")
            image_path = ""
            if image_name and images_root:
                candidate = Path(str(images_root)) / image_name
                if candidate.exists():
                    image_path = str(candidate)
                else:
                    # 3.1.0: was silently stored as NULL -> `-i .` at
                    # export. Warn loud and early instead (RULE 7).
                    ctx["warnings"].append(
                        f"Scene {index}: image '{image_name}' not "
                        "found in the images folder — export stops "
                        "until it exists"
                    )
            elif not image_name:
                ctx["warnings"].append(
                    f"Scene {index}: no image mapped in the script"
                )
            saved = self.db.save_scene(
                {
                    "id": scene_id,
                    "project_id": project_id,
                    "scene_number": int(scene.get("scene_number") or index),
                    "image_filename": image_name,
                    "image_file_path": image_path or None,
                    "transition_in": scene.get("transition_in") or "crossfade",
                    "transition_out": scene.get("transition_out") or "crossfade",
                    "animation_type": scene.get("animation") or "ken_burns",
                }
            )
            if not saved:
                ctx["warnings"].append(
                    f"scene {index} could not be persisted"
                )
                continue
            for line_no, line in enumerate(scene.get("dialogue") or [], start=1):
                self.db.db.execute(
                    "INSERT INTO dialogue_lines (id, project_id, scene_id,"
                    " line_number, character_name, emotion, text_content,"
                    " pause_after, created_at, updated_at)"
                    " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        self.db.new_id(),
                        project_id,
                        scene_id,
                        line_no,
                        str(line.get("character") or "NARRATOR").upper(),
                        str(line.get("emotion") or "neutral"),
                        str(line.get("text") or ""),
                        str(line.get("pause_after") or "short"),
                        utc_now_str(),
                        utc_now_str(),
                    ),
                )

    # ------------------------------------------------------------------
    # Stages 2-4: profile, voices, keywords
    # ------------------------------------------------------------------
    def _stage_channel_profile(
        self, manager: Any, ctx: Dict[str, Any]
    ) -> Dict[str, Any]:
        ref = ctx.get("channel_profile_id")
        if not ref:
            return {"success": True, "data": {"skipped": "no profile ref"}}
        result = manager.apply_profile_to_project(ctx["project_id"], str(ref))
        if result.get("success"):
            return result
        # A stale/missing profile ref must not kill the render.
        return {"success": False, "error": result.get("error") or "apply failed"}

    def _stage_voice_profiles(
        self, manager: Any, ctx: Dict[str, Any]
    ) -> Dict[str, Any]:
        data = ctx.get("parsed_data")
        if data:
            return manager.create_profiles_from_script(data, ctx["project_id"])
        existing = manager.get_all_profiles(ctx["project_id"])
        if existing.get("success") and existing.get("data", {}).get("profiles"):
            return {"success": True, "data": {"reused_existing": True}}
        return {
            "success": False,
            "error": "no parsed script data and no existing profiles",
        }

    def _stage_keywords(self, analyzer: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        return analyzer.analyze_all_scenes(ctx["project_id"])

    # ------------------------------------------------------------------
    # Stage 5: quality gate (advisory by default)
    # ------------------------------------------------------------------
    def _stage_quality_gate(self, checker: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        self._transition(RenderState.VALIDATING, "pre-render checks")
        result = checker.run_full_check(ctx["project_id"])
        if not result.get("success"):
            return result
        data = result.get("data") or {}
        # run_full_check already applied every registered auto-fix.
        readiness = bool(data.get("is_render_ready", True))
        ctx["warnings"].append(
            "quality: " + ("READY" if readiness else "NOT READY")
            + f" ({data.get('passed', '?')}/{data.get('total_checks', '?')})"
        )
        if ctx.get("quality_gate") and not readiness:
            return {
                "success": False,
                "hard_fail": True,
                "error": "quality gate: unresolved critical/error issues",
                "data": {"is_render_ready": False},
            }
        return {"success": True, "data": {"is_render_ready": readiness}}

    # ------------------------------------------------------------------
    # Stages 6-8: images, tts, sfx
    # ------------------------------------------------------------------
    def _stage_images(self, processor: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        self._transition(RenderState.GENERATING, "image processing")
        return processor.process_all_images(ctx["project_id"])

    def _stage_tts(self, tts: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        lines = self.db.db.fetch_all(
            "SELECT dl.*, s.scene_number FROM dialogue_lines dl"
            " JOIN scenes s ON s.id = dl.scene_id"
            " WHERE dl.project_id = ?"
            " ORDER BY s.scene_number, dl.line_number",
            (ctx["project_id"],),
        )
        if not lines:
            return {"success": False, "error": "no dialogue lines to synthesize"}
        audio_dir = Path(str(ctx["project_folder"])) / "audio"
        audio_dir.mkdir(parents=True, exist_ok=True)
        profiles = self._modules.get("voice_profile_manager")
        line_paths: List[str] = []
        offset_seconds = 0.0
        generated = 0
        failures = 0
        for index, row in enumerate(lines):
            if self._cancel_requested:
                return {
                    "success": False, "cancelled": True,
                    "error": "pipeline cancelled during tts",
                }
            text = str(row.get("text_content") or "").strip()
            if not text:
                continue
            character = str(row.get("character_name") or "NARRATOR")
            char_profile = self._character_profile(
                profiles, ctx["project_id"], character
            )
            out_path = audio_dir / f"line_{index:03d}.wav"
            gen = tts.generate_audio(text, char_profile, out_path)
            if not gen.get("success"):
                failures += 1
                ctx["warnings"].append(
                    f"tts line {index} ({character}): {gen.get('error')}"
                )
                continue
            gdata = gen.get("data") or {}
            audio_path = _pick_path(gdata, "audio_path") or str(out_path)
            duration = float(gdata.get("duration") or 0.5)
            self.db.db.execute(
                "UPDATE dialogue_lines SET audio_generated = 1,"
                " audio_file_path = ?, audio_duration = ?,"
                " word_timestamps_json = ?, status = 'completed'"
                " WHERE id = ?",
                (
                    str(audio_path),
                    duration,
                    json.dumps(gdata.get("word_timestamps") or []),
                    row["id"],
                ),
            )
            self._insert_word_timestamps(
                ctx["project_id"],
                row["id"],
                gdata.get("word_timestamps") or [],
                offset_seconds,
            )
            offset_seconds += duration + _PAUSE_BETWEEN_LINES
            line_paths.append(str(audio_path))
            generated += 1
        if generated == 0:
            return {
                "success": False,
                "error": f"tts produced no audio ({failures} line failures)",
            }
        ctx["line_audio_paths"] = line_paths
        ctx["narration_duration"] = max(0.0, offset_seconds - _PAUSE_BETWEEN_LINES)
        return {
            "success": True,
            "data": {"lines_generated": generated, "lines_failed": failures},
        }

    def _character_profile(
        self, profiles: Optional[Any], project_id: str, character: str
    ) -> Dict[str, Any]:
        """Voice profile for a character (alias-resolved, safe defaults)."""
        row: Optional[Dict[str, Any]] = None
        if profiles is not None:
            canonical = character
            try:
                resolved = profiles.resolve_character_alias(project_id, character)
                if resolved:
                    canonical = resolved
                loaded = profiles.load_profile(project_id, canonical)
                if loaded.get("success"):
                    row = (loaded.get("data") or {}).get("profile")
            except Exception:  # noqa: BLE001 - defaults are fine
                row = None
        row = row or {}
        return {
            "engine": row.get("engine") or "piper",
            "voice_model": row.get("voice_model") or "default",
            "speed": float(row.get("speed") or 1.0),
            "pitch": float(row.get("pitch") or 0.0),
            "volume": float(row.get("volume") or 1.0),
            "default_emotion": row.get("default_emotion") or "neutral",
            "reverb_preset": row.get("reverb_preset") or "none",
            "eq_preset": row.get("eq_preset") or "flat",
            "breathing_enabled": bool(row.get("breathing_enabled")),
        }

    def _insert_word_timestamps(
        self,
        project_id: str,
        dialogue_line_id: str,
        words: List[Dict[str, Any]],
        offset_seconds: float,
    ) -> None:
        """Persist TTS word timings as narration-absolute milliseconds.

        generate_audio's word dicts are line-relative seconds
        ({word, start, end}); subtitles need absolute ms across the
        joined narration track, so the orchestrator accumulates line
        durations + the narration pause constant as it goes (this is
        wiring glue, not module logic - it lives here, not in a module).
        """
        for word_index, word in enumerate(words):
            text = str(word.get("word") or word.get("word_text") or "")
            if not text:
                continue
            start_s = float(word.get("start") or word.get("start_time_ms", 0.0))
            end_s = float(word.get("end") or word.get("end_time_ms", 0.0))
            if word.get("start_time_ms") is not None:
                start_ms = int(float(word["start_time_ms"]) + offset_seconds * 1000)
            else:
                start_ms = int((start_s + offset_seconds) * 1000)
            if word.get("end_time_ms") is not None:
                end_ms = int(float(word["end_time_ms"]) + offset_seconds * 1000)
            else:
                end_ms = int((end_s + offset_seconds) * 1000)
            self.db.db.execute(
                "INSERT INTO word_timestamps (id, project_id,"
                " dialogue_line_id, word_index, word_text, start_time_ms,"
                " end_time_ms) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    self.db.new_id(),
                    project_id,
                    dialogue_line_id,
                    word_index,
                    text,
                    max(0, start_ms),
                    max(0, end_ms),
                ),
            )

    def _stage_sfx(self, sfx: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        library = sfx.load_sfx_library()
        if not library.get("success"):
            return library
        placed = sfx.auto_place_sfx(ctx["project_id"])
        if not placed.get("success"):
            return placed
        prepared = sfx.prepare_sfx_for_mixing(ctx["project_id"])
        if prepared.get("success"):
            ctx["sfx_list"] = (prepared.get("data") or {}).get("sfx_list") or []
        return {"success": True, "data": {"prepared": len(ctx.get("sfx_list") or [])}}

    # ------------------------------------------------------------------
    # Stage 9: final mix; Stage 10: SRT
    # ------------------------------------------------------------------
    def _stage_audio_mix(self, audio: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        music = None
        project = self.db.db.fetch_one(
            "SELECT music_file_path FROM projects WHERE id = ?",
            (ctx["project_id"],),
        )
        if project and project.get("music_file_path"):
            music = str(project["music_file_path"])
        out_path = Path(str(ctx["project_folder"])) / "audio" / "final_mix.wav"
        settings = {
            "line_paths": ctx.get("line_audio_paths") or [],
        }
        if music:
            settings["music_path"] = music
        if ctx.get("sfx_list"):
            settings["sfx_list"] = ctx["sfx_list"]
        mixed = audio.generate_final_mix(ctx["project_id"], out_path, settings)
        if not mixed.get("success"):
            return mixed
        ctx["final_mix"] = _pick_path(mixed.get("data") or {}, "audio_path") or str(
            out_path
        )
        return {"success": True, "data": {"final_mix": ctx["final_mix"]}}

    def _stage_subtitles(self, engine: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        self._transition(RenderState.PROCESSING, "subtitles")
        project = self.db.db.fetch_one(
            "SELECT has_subtitles FROM projects WHERE id = ?",
            (ctx["project_id"],),
        )
        if project and not int(project.get("has_subtitles") or 0):
            return {"success": True, "data": {"skipped": "has_subtitles=0"}}
        result = engine.generate_srt_from_word_timestamps(ctx["project_id"])
        if result.get("success"):
            data = result.get("data") or {}
            ctx["srt_path"] = _pick_path(
                data, "srt_path", "file_path", "output_path"
            )
        return result

    # ------------------------------------------------------------------
    # Stage 11: intro/outro; Stage 12: timeline
    # ------------------------------------------------------------------
    def _stage_intro_outro(self, engine: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        intro = engine.generate_intro(ctx["project_id"])
        outro = engine.generate_outro(ctx["project_id"])
        made: Dict[str, Any] = {}
        for key, result in (("intro", intro), ("outro", outro)):
            data = (result or {}).get("data") or {}
            if result.get("success") and not data.get("skipped"):
                path = _pick_path(data, "segment_path", "output_path", "video_path")
                if path:
                    made[key] = {
                        "path": path,
                        "duration": float(data.get("duration") or 0.0),
                    }
        ctx["intro_outro_segments"] = made
        return {"success": True, "data": {"segments": sorted(made)}}

    def _stage_timeline(self, engine: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        io_config = None
        intro_engine = self._modules.get("intro_outro_engine")
        if intro_engine is not None and getattr(intro_engine, "enabled", True):
            try:
                resolved = intro_engine.get_intro_outro_settings(ctx["project_id"])
                if resolved.get("success"):
                    io_config = resolved.get("data") or {}
            except Exception:  # noqa: BLE001 - timeline defaults suffice
                io_config = None
        intro_cfg = (io_config or {}).get("intro") or {}
        outro_cfg = (io_config or {}).get("outro") or {}
        built = engine.build_timeline(
            ctx["project_id"],
            narration_path=ctx.get("final_mix"),
            intro_config={
                "enabled": bool(intro_cfg.get("enabled", False)),
                "duration": float(intro_cfg.get("duration") or 5.0),
                "type": "generated",
            },
            outro_config={
                "enabled": bool(outro_cfg.get("enabled", False)),
                "duration": float(outro_cfg.get("duration") or 20.0),
                "type": "generated",
            },
            save=True,
        )
        if not built.get("success"):
            return built
        timeline = (built.get("data") or {}).get("timeline") or {}
        if ctx.get("final_mix"):
            timeline["audio_path"] = ctx["final_mix"]
        ctx["timeline"] = timeline
        return {
            "success": True,
            "data": {"total_duration": timeline.get("total_duration")},
        }

    # ------------------------------------------------------------------
    # Stages 13-14: export render + join
    # ------------------------------------------------------------------
    def _stage_export(self, engine: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        self._transition(RenderState.RENDERING, "scene renders")
        timeline = ctx.get("timeline") or {}
        preset = ctx.get("export_preset")
        animation_engine = self._modules.get("animation_engine")
        grade_engine = self._modules.get("color_grade_engine")
        project = self.db.db.fetch_one(
            "SELECT color_grade_preset FROM projects WHERE id = ?",
            (ctx["project_id"],),
        )
        grade_name = str((project or {}).get("color_grade_preset") or "")
        grade_filter = ""
        grade_extras: Dict[str, Any] = {}
        if grade_engine is not None and grade_name:
            built = grade_engine.build_grade_filter(grade_name)
            if built.get("success"):
                gdata = built.get("data") or {}
                grade_filter = str(gdata.get("filtergraph") or "")
                grade_extras = gdata.get("extras") or {}
            else:
                ctx["warnings"].append(
                    f"grade '{grade_name}' unavailable: {built.get('error')}"
                )

        scenes = self.db.db.fetch_all(
            "SELECT * FROM scenes WHERE project_id = ? ORDER BY scene_number",
            (ctx["project_id"],),
        )
        if not scenes:
            return {"success": False, "error": "no scenes to render"}
        segments_dir = Path(str(ctx["project_folder"])) / "segments"
        segments_dir.mkdir(parents=True, exist_ok=True)
        segments: List[Dict[str, Any]] = []
        io_segments = ctx.get("intro_outro_segments") or {}
        if io_segments.get("intro"):
            segments.append(
                {"path": io_segments["intro"]["path"],
                 "duration": io_segments["intro"]["duration"] or 5.0}
            )
        progress_cb = self._progress_forwarder(ctx)
        for index, scene in enumerate(scenes):
            if self._cancel_requested:
                return {
                    "success": False, "cancelled": True,
                    "error": "pipeline cancelled during render",
                }
            scene_dict = self._scene_for_render(
                scene, timeline, str(ctx.get("images_folder") or "")
            )
            anim_filter = ""
            if animation_engine is not None:
                anim = animation_engine.get_zoompan_filter(
                    str(scene_dict.get("animation_type") or "ken_burns"),
                    float(scene_dict.get("duration") or 8.0),
                    intensity=str(scene_dict.get("animation_intensity") or "medium"),
                )
                if anim.get("success"):
                    anim_filter = str(
                        (anim.get("data") or {}).get("filter_string") or ""
                    )
            out_path = segments_dir / f"scene_{index:03d}.mp4"
            rendered = engine.render_scene_to_video(
                scene_dict,
                anim_filter,
                grade_filter,
                out_path,
                preset=preset,
                grade_extras=grade_extras,
                progress_callback=progress_cb,
            )
            if not rendered.get("success"):
                return {
                    "success": False,
                    "error": f"scene {index} render failed: {rendered.get('error')}",
                }
            seg_path = _pick_path(
                rendered.get("data") or {}, "output_path", "video_path"
            ) or str(out_path)
            segments.append(
                {"path": seg_path,
                 "duration": float(scene_dict.get("duration") or 8.0)}
            )
        if io_segments.get("outro"):
            segments.append(
                {"path": io_segments["outro"]["path"],
                 "duration": io_segments["outro"]["duration"] or 20.0}
            )

        self._transition(RenderState.EXPORTING, "join+mux")
        joined_path = (
            Path(str(ctx["project_folder"])) / "output" / "joined.mp4"
        )
        joined_path.parent.mkdir(parents=True, exist_ok=True)
        joined = engine.join_segments_with_transitions(
            segments, timeline, joined_path, preset=preset,
            progress_callback=progress_cb,
        )
        if not joined.get("success"):
            return joined
        ctx["joined_output"] = str(joined_path)
        return {"success": True, "data": {"segments": len(segments)}}

    def _scene_for_render(
        self,
        scene: Dict[str, Any],
        timeline: Dict[str, Any],
        images_root: str = "",
    ) -> Dict[str, Any]:
        """Scene dict for render_scene_to_video (image path resolution).

        Prefers the processed 1920x1080 asset; falls back to the raw
        scene image path (image_processor marks assets by original
        file path - column resolved via PRAGMA to survive schema drift).
        """
        raw = str(scene.get("image_file_path") or "")
        if not raw and images_root:
            # 3.1.0 self-heal: re-derive from the stored filename
            # (project moved / NULL slipped through an older run).
            candidate = Path(images_root) / str(
                scene.get("image_filename") or "")
            if candidate.is_file():
                raw = str(candidate)
        processed = self._processed_image_for(raw)
        timeline_scene = self._timeline_scene_for(
            timeline, int(scene.get("scene_number") or 0)
        )
        duration = float(
            scene.get("duration")
            or (timeline_scene or {}).get("duration")
            or 8.0
        )
        return {
            "id": scene.get("id"),
            "scene_number": scene.get("scene_number"),
            "image_path": processed or raw,
            "image": raw,
            "duration": duration,
            "animation_type": scene.get("animation_type")
            or (timeline_scene or {}).get("animation_type")
            or "ken_burns",
            "animation_intensity": scene.get("animation_intensity") or "medium",
        }

    def _processed_image_for(self, raw_path: str) -> Optional[str]:
        if not raw_path:
            return None
        column = self._image_assets_column()
        if not column:  # schema lacks a usable path column
            return None
        # D2a: resolve the path column via PRAGMA once (cached) instead
        # of try/erroring between candidate names — the failed probe
        # made database_service log a misleading ERROR per scene.
        try:
            row = self.db.db.fetch_one(
                "SELECT processed_file_path FROM image_assets"
                f" WHERE {column} = ? AND processed_file_path IS NOT NULL",
                (raw_path,),
            )
        except Exception:  # noqa: BLE001 - schema drift tolerated
            return None
        if row and row.get("processed_file_path"):
            candidate = Path(str(row["processed_file_path"]))
            if candidate.exists():
                return str(candidate)
        return None

    def _image_assets_column(self) -> Optional[str]:
        """Path column of image_assets, resolved once via PRAGMA.

        Caches both positive and negative outcomes in
        self._assets_col_cache ("" marks 'checked, none usable').
        """
        cache = getattr(self, "_assets_col_cache", None)
        if cache is not None:
            return cache or None
        names: set = set()
        try:
            rows = self.db.db.fetch_all("PRAGMA table_info(image_assets)")
            names = {str(r.get("name")) for r in (rows or [])}
        except Exception:  # noqa: BLE001 - PRAGMA never expected to fail
            names = set()
        column = ""
        if "processed_file_path" in names:
            for candidate in ("file_path", "original_file_path"):
                if candidate in names:
                    column = candidate
                    break
        self._assets_col_cache = column
        return column or None

    @staticmethod
    def _timeline_scene_for(
        timeline: Dict[str, Any], scene_number: int
    ) -> Optional[Dict[str, Any]]:
        for scene in (timeline or {}).get("scenes") or []:
            try:
                if int(scene.get("scene_number") or 0) == scene_number:
                    return scene
            except (TypeError, ValueError):
                continue
        return None

    def _stage_burn_subtitles(self, engine: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        srt = ctx.get("srt_path")
        joined = ctx.get("joined_output")
        if not srt or not Path(str(srt)).exists():
            ctx["final_output"] = joined
            return {"success": True, "data": {"skipped": "no srt"}}
        project = self.db.db.fetch_one(
            "SELECT has_subtitles, default_subtitle_style, title FROM projects"
            " WHERE id = ?",
            (ctx["project_id"],),
        )
        if project and not int(project.get("has_subtitles") or 0):
            ctx["final_output"] = joined
            return {"success": True, "data": {"skipped": "has_subtitles=0"}}
        final_path = self._final_output_path(ctx)
        style = str((project or {}).get("default_subtitle_style") or "word_by_word")
        burned = engine.burn_subtitles(str(joined), str(srt), style, final_path)
        if burned.get("success"):
            ctx["final_output"] = str(final_path)
            return burned
        # Burn failure keeps the joined (unsubtitled) video as output.
        ctx["warnings"].append(
            f"subtitle burn failed; shipping unsubtitled video: {burned.get('error')}"
        )
        ctx["final_output"] = joined
        return {"success": True, "data": {"fell_back_to_joined": True}}

    def _final_output_path(self, ctx: Dict[str, Any]) -> Path:
        project = self.db.db.fetch_one(
            "SELECT title FROM projects WHERE id = ?", (ctx["project_id"],)
        )
        title = str((project or {}).get("title") or "video")
        safe_title = "".join(
            c if c.isalnum() or c in "-_ " else "" for c in title
        ).strip().replace(" ", "_") or "video"
        preset = str(ctx.get("export_preset") or "youtube_1080p")
        date = utc_now_str().split(" ")[0]
        name = f"{safe_title}_{preset}_{date}.mp4"
        out_dir = Path(str(ctx["project_folder"])) / "output"
        out_dir.mkdir(parents=True, exist_ok=True)
        return out_dir / name

    def _stage_verify(self, engine: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        output = ctx.get("final_output")
        if not output:
            return {"success": False, "error": "no output to verify"}
        expected = float(
            (ctx.get("timeline") or {}).get("total_duration")
            or ctx.get("narration_duration")
            or 0.0
        )
        if expected <= 0.0:
            path = Path(str(output))
            if path.exists() and path.stat().st_size > 0:
                return {
                    "success": True,
                    "data": {"verified": False,
                             "reason": "no expected duration available"},
                }
            return {"success": False, "error": f"output missing: {output}"}
        checked = engine.verify_output(str(output), expected)
        return checked

    def _stage_thumbnails(self, generator: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        return generator.auto_generate_for_project(ctx["project_id"])

    # ------------------------------------------------------------------
    # Stage 17: Google Drive backup (D.7 - optional, self-skipping)
    # ------------------------------------------------------------------
    def _stage_drive_upload(self, engine: Any, ctx: Dict[str, Any]) -> Dict[str, Any]:
        output = _pick_path(ctx, "final_output")
        if not output:
            return {
                "success": True,
                "data": {"skipped": "no rendered file to upload"},
            }
        return engine.upload_final_render(
            output,
            project_id=ctx.get("project_id"),
            title=ctx.get("project_title"),
        )

    # ------------------------------------------------------------------
    # Finalization + helpers
    # ------------------------------------------------------------------
    def _finalize_success(self, ctx: Dict[str, Any]) -> None:
        self._transition(RenderState.COMPLETE, "pipeline finished")
        self.db.db.execute(
            "UPDATE projects SET status = 'completed',"
            " render_count = COALESCE(render_count, 0) + 1,"
            " last_render_at = ?, last_render_output_path = ?, updated_at = ?"
            " WHERE id = ?",
            (utc_now_str(), ctx.get("final_output"), utc_now_str(),
             ctx["project_id"]),
        )

    def _progress_forwarder(self, ctx: Dict[str, Any]) -> Callable[..., None]:
        """Forward module progress callbacks onto the event bus.

        Signature mirrors export_engine.monitor_ffmpeg_progress, which
        invokes callback(progress, fps, eta_seconds) with three
        positional floats. D2a hotfix: the Windows D.3 smoke (first run
        against REAL ffmpeg, which emits frame=/fps= lines) exposed
        that the previous single-arg forwarder crashed the export
        stage; POSIX fakes emit no progress lines so tests never
        invoked it. All three args default so any call shape works.
        """

        def _forward(
            progress: Any = 0.0, fps: Any = 0.0, eta: Any = 0.0
        ) -> None:
            self.event_bus.publish(
                "pipeline.render_progress",
                {
                    "project_id": ctx.get("project_id"),
                    "progress": progress,
                    "fps": fps,
                    "eta_seconds": eta,
                },
            )

        return _forward

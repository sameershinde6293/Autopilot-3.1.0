"""Disk-backed caching layer for Autopilot.

Caches expensive intermediate results (proxy images, analysis, etc.)
with TTL and max-size eviction. Prefer disk over RAM per lazy-loading rules.
"""

from __future__ import annotations

import hashlib
import json
import logging
import shutil
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger("autopilot.cache")


class CacheService:
    """File-system cache with metadata index and size limits."""

    def __init__(
        self,
        cache_folder: str | Path = "cache",
        max_size_mb: int = 2048,
        default_ttl_seconds: int = 7 * 24 * 3600,
    ) -> None:
        """Initialize cache service.

        Args:
            cache_folder: Root cache directory.
            max_size_mb: Maximum total cache size in megabytes.
            default_ttl_seconds: Default entry lifetime.
        """
        self.cache_folder = Path(cache_folder)
        self.max_size_bytes = max_size_mb * 1024 * 1024
        self.default_ttl_seconds = default_ttl_seconds
        self._lock = threading.RLock()
        self.cache_folder.mkdir(parents=True, exist_ok=True)
        self._index_path = self.cache_folder / "cache_index.json"
        self._index: Dict[str, Dict[str, Any]] = self._load_index()

    def _load_index(self) -> Dict[str, Dict[str, Any]]:
        """Load cache index from disk."""
        if not self._index_path.exists():
            return {}
        try:
            with self._index_path.open("r", encoding="utf-8") as handle:
                data = json.load(handle)
            return data if isinstance(data, dict) else {}
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning("Cache index corrupt, starting empty: %s", exc)
            return {}

    def _save_index(self) -> None:
        """Persist cache index to disk."""
        try:
            with self._index_path.open("w", encoding="utf-8") as handle:
                json.dump(self._index, handle, indent=2)
        except OSError as exc:
            logger.error("Failed to save cache index: %s", exc)

    # Windows-forbidden filename characters: < > : " / \ | ? * and control chars.
    _UNSAFE_FILENAME_CHARS = '<>:"/\\|?*'

    @staticmethod
    def make_key(*parts: str) -> str:
        """Build a stable cache key from string parts.

        Args:
            *parts: Key components.

        Returns:
            SHA256 hex digest (safe for filenames).
        """
        raw = "|".join(parts)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    @classmethod
    def sanitize_filename(cls, key: str, max_length: int = 180) -> str:
        """Sanitize a cache key for use as a filesystem path segment.

        Logical keys may contain characters illegal on Windows (e.g. ':').
        The original key remains the index dictionary key; only the on-disk
        name is sanitized.

        Args:
            key: Logical cache key.
            max_length: Maximum filename length before hashing.

        Returns:
            Filesystem-safe filename stem (no directory separators).
        """
        text = str(key or "empty")
        # Normalize path separators first
        text = text.replace("\\", "_").replace("/", "_")
        sanitized_chars: list[str] = []
        for char in text:
            if char in cls._UNSAFE_FILENAME_CHARS or ord(char) < 32:
                sanitized_chars.append("_")
            else:
                sanitized_chars.append(char)
        sanitized = "".join(sanitized_chars).strip(" .")
        if not sanitized:
            sanitized = "cache_entry"
        # Avoid Windows reserved device names
        reserved = {
            "CON",
            "PRN",
            "AUX",
            "NUL",
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8",
            "COM9",
            "LPT1",
            "LPT2",
            "LPT3",
            "LPT4",
            "LPT5",
            "LPT6",
            "LPT7",
            "LPT8",
            "LPT9",
        }
        if sanitized.upper() in reserved:
            sanitized = f"_{sanitized}"
        if len(sanitized) > max_length:
            digest = hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]
            sanitized = f"{sanitized[: max_length - 17]}_{digest}"
        return sanitized

    def _entry_path(self, key: str, suffix: str = ".bin") -> Path:
        """Return filesystem path for a cache key (Windows-safe filename)."""
        safe_name = self.sanitize_filename(key)
        # Shard by first two chars of the *safe* name for even distribution
        sub = safe_name[:2] if len(safe_name) >= 2 else "00"
        folder = self.cache_folder / sub
        folder.mkdir(parents=True, exist_ok=True)
        if suffix and not suffix.startswith("."):
            suffix = f".{suffix}"
        return folder / f"{safe_name}{suffix}"

    def get(self, key: str) -> Optional[bytes]:
        """Read a binary cache entry if present and not expired.

        Args:
            key: Cache key.

        Returns:
            Bytes or None.
        """
        with self._lock:
            meta = self._index.get(key)
            if not meta:
                return None
            expires_at = float(meta.get("expires_at", 0))
            if expires_at and time.time() > expires_at:
                self.delete(key)
                return None
            path = Path(meta.get("path", self._entry_path(key)))
            if not path.exists():
                self._index.pop(key, None)
                self._save_index()
                return None
            try:
                data = path.read_bytes()
                meta["last_access"] = time.time()
                self._save_index()
                return data
            except OSError as exc:
                logger.error("Cache read failed for %s: %s", key, exc)
                return None

    def get_json(self, key: str) -> Optional[Any]:
        """Read a JSON cache entry.

        Args:
            key: Cache key.

        Returns:
            Parsed JSON or None.
        """
        raw = self.get(key)
        if raw is None:
            return None
        try:
            return json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return None

    def set(
        self,
        key: str,
        data: bytes,
        ttl_seconds: Optional[int] = None,
        suffix: str = ".bin",
    ) -> bool:
        """Write a binary cache entry.

        Args:
            key: Cache key.
            data: Payload bytes.
            ttl_seconds: Optional TTL override.
            suffix: File suffix.

        Returns:
            True on success.
        """
        ttl = self.default_ttl_seconds if ttl_seconds is None else ttl_seconds
        path = self._entry_path(key, suffix=suffix)
        with self._lock:
            try:
                path.write_bytes(data)
                self._index[key] = {
                    "path": str(path),
                    "size": len(data),
                    "created_at": time.time(),
                    "last_access": time.time(),
                    "expires_at": time.time() + ttl if ttl > 0 else 0,
                }
                self._save_index()
                self._enforce_size_limit()
                return True
            except OSError as exc:
                logger.error("Cache write failed for %s: %s", key, exc)
                return False

    def set_json(
        self,
        key: str,
        value: Any,
        ttl_seconds: Optional[int] = None,
    ) -> bool:
        """Write a JSON-serializable value to cache.

        Args:
            key: Cache key.
            value: JSON-serializable object.
            ttl_seconds: Optional TTL.

        Returns:
            True on success.
        """
        payload = json.dumps(value, ensure_ascii=False).encode("utf-8")
        return self.set(key, payload, ttl_seconds=ttl_seconds, suffix=".json")

    def delete(self, key: str) -> bool:
        """Delete a cache entry.

        Args:
            key: Cache key.

        Returns:
            True if removed or already absent.
        """
        with self._lock:
            meta = self._index.pop(key, None)
            self._save_index()
            if not meta:
                return True
            path = Path(meta.get("path", ""))
            try:
                if path.exists():
                    path.unlink()
                return True
            except OSError as exc:
                logger.error("Cache delete failed for %s: %s", key, exc)
                return False

    def clear(self) -> None:
        """Remove all cache entries and index."""
        with self._lock:
            for key in list(self._index.keys()):
                self.delete(key)
            self._index.clear()
            self._save_index()

    def get_size_bytes(self) -> int:
        """Return total size of tracked cache entries in bytes."""
        with self._lock:
            return int(sum(int(m.get("size", 0)) for m in self._index.values()))

    def get_size_mb(self) -> float:
        """Return total cache size in megabytes."""
        return self.get_size_bytes() / 1024 / 1024

    def _enforce_size_limit(self) -> None:
        """Evict least-recently-accessed entries until under max size."""
        total = self.get_size_bytes()
        if total <= self.max_size_bytes:
            return
        ordered = sorted(
            self._index.items(),
            key=lambda item: float(item[1].get("last_access", 0)),
        )
        for key, meta in ordered:
            if total <= self.max_size_bytes:
                break
            size = int(meta.get("size", 0))
            self.delete(key)
            total -= size
            logger.debug("Evicted cache key %s (%s bytes)", key, size)

    def put_file(
        self, key: str, source_path: str | Path, ttl_seconds: Optional[int] = None
    ) -> bool:
        """Copy an existing file into the cache.

        Args:
            key: Cache key.
            source_path: Source file path.
            ttl_seconds: Optional TTL.

        Returns:
            True on success.
        """
        source = Path(source_path)
        if not source.exists():
            return False
        try:
            data = source.read_bytes()
        except OSError:
            return False
        return self.set(
            key, data, ttl_seconds=ttl_seconds, suffix=source.suffix or ".bin"
        )

    def copy_to(self, key: str, dest_path: str | Path) -> bool:
        """Copy a cache entry to a destination path.

        Args:
            key: Cache key.
            dest_path: Destination file path.

        Returns:
            True on success.
        """
        with self._lock:
            meta = self._index.get(key)
            if not meta:
                return False
            src = Path(meta["path"])
            if not src.exists():
                return False
            dest = Path(dest_path)
            dest.parent.mkdir(parents=True, exist_ok=True)
            try:
                shutil.copy2(src, dest)
                return True
            except OSError as exc:
                logger.error("Cache copy failed: %s", exc)
                return False

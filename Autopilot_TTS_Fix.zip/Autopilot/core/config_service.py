"""Unified configuration service for Autopilot.

Loads JSON config files from the config folder once and provides typed
access. Missing or corrupt files fall back to in-memory defaults.
"""

from __future__ import annotations

import json
import logging
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("autopilot.config")

CONFIG_FILES: Tuple[str, ...] = (
    "app_settings.json",
    "modules_config.json",
    "keyboard_shortcuts.json",
    "export_presets.json",
    "color_grade_presets.json",
    "transition_presets.json",
    "animation_presets.json",
    "subtitle_style_presets.json",
    "sfx_config.json",
    "voice_store_catalog.json",
    "documentary_genres.json",
    "keyword_emotion_map.json",
    "ffmpeg_commands.json",
    "default_channel_profile.json",
    "drive_upload.json",
    "plugins_config.json",
)


class ConfigService:
    """Loads and caches all JSON configuration files."""

    def __init__(self, config_folder: str | Path = "config") -> None:
        """Initialize config service.

        Args:
            config_folder: Path to the config directory.
        """
        self.config_folder = Path(config_folder)
        self._cache: Dict[str, Any] = {}
        self._lock = threading.RLock()
        self._load_all()

    def _load_all(self) -> None:
        """Load every known config file into the cache."""
        self.config_folder.mkdir(parents=True, exist_ok=True)
        for filename in CONFIG_FILES:
            self._load_file(filename)

    def _load_file(self, filename: str) -> Any:
        """Load one JSON file into cache with safe fallbacks.

        Args:
            filename: Config file name (e.g. app_settings.json).

        Returns:
            Parsed JSON object or empty dict/list default.
        """
        path = self.config_folder / filename
        key = filename.replace(".json", "")
        try:
            if not path.exists():
                logger.warning("Config missing: %s — using empty default", path)
                default: Any = (
                    []
                    if "presets" in filename or filename.endswith("_map.json")
                    else {}
                )
                # Prefer dict for most; lists for some catalogs
                if filename in (
                    "export_presets.json",
                    "color_grade_presets.json",
                    "transition_presets.json",
                    "animation_presets.json",
                    "subtitle_style_presets.json",
                    "documentary_genres.json",
                ):
                    default = (
                        {"presets": []} if "presets" in filename else {"genres": []}
                    )
                self._cache[key] = default
                return default
            with path.open("r", encoding="utf-8") as handle:
                data = json.load(handle)
            self._cache[key] = data
            logger.debug("Loaded config: %s", filename)
            return data
        except json.JSONDecodeError as exc:
            logger.error("Config file corrupted %s: %s", path, exc)
            self._cache[key] = {}
            return {}
        except OSError as exc:
            logger.error("Config file unreadable %s: %s", path, exc)
            self._cache[key] = {}
            return {}

    def reload(self, filename: Optional[str] = None) -> None:
        """Reload one file or all config files.

        Args:
            filename: Optional specific file; None reloads all.
        """
        with self._lock:
            if filename is None:
                self._cache.clear()
                self._load_all()
            else:
                self._load_file(filename)

    def get_config(self, name: str) -> Any:
        """Return a full config object by short name.

        Args:
            name: Name without .json (e.g. 'app_settings').

        Returns:
            Cached config data.
        """
        with self._lock:
            if name not in self._cache:
                self._load_file(f"{name}.json")
            return self._cache.get(name, {})

    def get(self, key: str, default: Any = None) -> Any:
        """Get a top-level app_settings value.

        Args:
            key: Setting key.
            default: Fallback value.

        Returns:
            Setting value or default.
        """
        settings = self.get_config("app_settings")
        if isinstance(settings, dict):
            # Support nested under "settings" or flat
            if key in settings:
                return settings[key]
            nested = settings.get("settings", {})
            if isinstance(nested, dict) and key in nested:
                return nested[key]
        return default

    def set(self, key: str, value: Any, persist: bool = True) -> bool:
        """Set an app_settings value and optionally write to disk.

        Args:
            key: Setting key.
            value: New value.
            persist: Write app_settings.json if True.

        Returns:
            True on success.
        """
        with self._lock:
            settings = self._cache.get("app_settings")
            if not isinstance(settings, dict):
                settings = {}
                self._cache["app_settings"] = settings
            settings[key] = value
            if not persist:
                return True
            return self._write_json("app_settings.json", settings)

    def get_module_config(self, module_name: str) -> Optional[Dict[str, Any]]:
        """Return module entry from modules_config.json.

        Args:
            module_name: Module name (e.g. 'file_parser').

        Returns:
            Module dict or None.
        """
        modules_cfg = self.get_config("modules_config")
        modules = (
            modules_cfg.get("modules", []) if isinstance(modules_cfg, dict) else []
        )
        for entry in modules:
            if isinstance(entry, dict) and entry.get("name") == module_name:
                return entry
        return None

    def is_module_enabled(self, module_name: str) -> bool:
        """Return whether a module is enabled.

        Args:
            module_name: Module name.

        Returns:
            True if enabled or not listed (default allow).
        """
        entry = self.get_module_config(module_name)
        if entry is None:
            return True
        return bool(entry.get("enabled", True))

    def list_config_files(self) -> List[str]:
        """Return names of config files present on disk.

        Returns:
            List of filenames.
        """
        return [path.name for path in sorted(self.config_folder.glob("*.json"))]

    def validate_all_json(self) -> Dict[str, bool]:
        """Validate each expected config file as parseable JSON.

        Returns:
            Map of filename -> valid bool.
        """
        results: Dict[str, bool] = {}
        for filename in CONFIG_FILES:
            path = self.config_folder / filename
            if not path.exists():
                results[filename] = False
                continue
            try:
                with path.open("r", encoding="utf-8") as handle:
                    json.load(handle)
                results[filename] = True
            except (OSError, json.JSONDecodeError):
                results[filename] = False
        return results

    def _write_json(self, filename: str, data: Any) -> bool:
        """Write JSON atomically-ish via temp file in same folder.

        Args:
            filename: Target file name.
            data: JSON-serializable data.

        Returns:
            True on success.
        """
        path = self.config_folder / filename
        temp_path = path.with_suffix(".tmp")
        try:
            with temp_path.open("w", encoding="utf-8") as handle:
                json.dump(data, handle, indent=2, ensure_ascii=False)
                handle.write("\n")
            temp_path.replace(path)
            return True
        except OSError as exc:
            logger.error("Failed to write config %s: %s", path, exc)
            if temp_path.exists():
                temp_path.unlink(missing_ok=True)
            return False

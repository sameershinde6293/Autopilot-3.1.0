#!/usr/bin/env python3
"""Autopilot entry point (D.2): boots the app and exposes the CLI.

Wires the pieces that have no business knowing about each other:

* finds the project root (dev checkout or PyInstaller-frozen exe dir),
* reads config/app_settings.json to build the production
  ServiceContainer,
* runs first-launch license initialization,
* dispatches subcommands to core.core_engine.CoreEngine -
  the ONLY pipeline orchestrator (RULE 1: modules never import each
  other; wiring lives in core_engine/main only).

CLI overview (all commands print concise status; exit 0 ok / 1 fail /
2 usage):

    python main.py render --script script.txt [--images DIR]
                          [--project-folder DIR] [--title T]
                          [--preset P] [--profile REF] [--quality-gate]
                          [--skip-license]
    python main.py render-project PROJECT_ID [--preset P]
                          [--quality-gate] [--skip-license]
    python main.py check PROJECT_ID
    python main.py batch-add [--project ID | --folder DIR]
    python main.py batch
    python main.py modules
    python main.py license [--activate KEY]
    python main.py ui          (D.4 seam: launches the PyQt shell)

The D.4 PyQt GUI (ui/) and the D.5 PyInstaller build both call into
these same helpers, so CLI/GUI/frozen paths share exactly one wiring.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.core_engine import CoreEngine
from core.license_manager import LicenseManager
from core.service_container import ServiceContainer

APP_NAME = "Autopilot"
APP_VERSION = "3.1.0"

EXIT_OK = 0
EXIT_FAIL = 1
EXIT_USAGE = 2


# ----------------------------------------------------------------------
# Bootstrapping
# ----------------------------------------------------------------------
def find_project_root() -> Path:
    """Locate the application root in dev or frozen (PyInstaller) mode.

    Dev: this main.py's folder. Frozen ONEDIR (D.5): PyInstaller 6
    places ALL bundled datas under `<exe folder>/_internal/` — config/,
    database/schema.sql, assets land there while runtime folders
    (database/*.db, logs/, temp/) are created inside it too, so the
    root is `_internal` when present. A `config/` next to the exe
    (custom overrides / older layouts) still wins when it exists.
    """
    if getattr(sys, "frozen", False):  # PyInstaller onefile/onedir
        exe_dir = Path(sys.executable).resolve().parent
        internal = exe_dir / "_internal"
        if (internal / "config").is_dir() and not (exe_dir / "config").is_dir():
            return internal
        return exe_dir
    return Path(__file__).resolve().parent


def load_app_settings(project_root: Path) -> Dict[str, Any]:
    """Bootstrap-read of app_settings.json (pre-container, RULE 8)."""
    path = project_root / "config" / "app_settings.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except (OSError, ValueError) as exc:
        print(f"[boot] warning: app_settings unreadable ({exc}); defaults")
    return {}


def _prepend_engine_dir_to_path(project_root: Path) -> Optional[Path]:
    """Put the bundled engines/ffmpeg dir on PATH (idempotent).

    Several libraries (pydub, and any subprocess-by-name call) look for
    ``ffmpeg``/``ffprobe`` on PATH instead of using HardwareService's
    configured hint. The portable app bundles both beside the config;
    prepending that folder makes them visible process-wide. On Windows
    CreateProcess/appends .exe automatically (ffmpeg.exe), so the same
    code path covers dev checkouts and the frozen exe.
    """
    engines_dir = project_root / "engines" / "ffmpeg"
    if not engines_dir.is_dir():
        return None
    current = os.environ.get("PATH", "")
    entry = str(engines_dir)
    if entry not in current.split(os.pathsep):
        os.environ["PATH"] = entry + os.pathsep + current
    return engines_dir


def build_container(project_root: Path) -> ServiceContainer:
    """Create the production service container for this app root."""
    _prepend_engine_dir_to_path(project_root)
    settings = load_app_settings(project_root)
    root = project_root

    def _resolve(value: Optional[str], fallback: str) -> str:
        raw = Path(str(value or fallback))
        return str(raw if raw.is_absolute() else root / raw)

    for folder_key, fallback in (
        ("temp_folder_path", "temp"),
        ("projects_folder_path", "projects"),
        ("cache_folder_path", "cache"),
        ("log_folder_path", "logs"),
    ):
        Path(_resolve(settings.get(folder_key), fallback)).mkdir(
            parents=True, exist_ok=True
        )
    (root / "config").mkdir(parents=True, exist_ok=True)
    (root / "database").mkdir(parents=True, exist_ok=True)

    app_config = {
        "database_path": _resolve(
            settings.get("database_path"), "database/autopilot.db"
        ),
        "schema_path": str(root / "database" / "schema.sql"),
        "config_folder": str(root / "config"),
        "cache_folder": _resolve(settings.get("cache_folder_path"), "cache"),
        "log_folder": _resolve(settings.get("log_folder_path"), "logs"),
        "ffmpeg_path": _resolve(
            settings.get("ffmpeg_path"), "engines/ffmpeg/ffmpeg"
        ),
    }
    return ServiceContainer.create_production_container(
        app_config=app_config, project_root=root
    )


def boot(project_root: Path) -> Dict[str, Any]:
    """Container + CoreEngine + license initialization (first launch)."""
    container = build_container(project_root)
    engine = CoreEngine(container)
    license_manager = LicenseManager(container)
    init = license_manager.initialize_license()
    lic_data = init.get("data") or {}
    return {
        "container": container,
        "engine": engine,
        "license": license_manager,
        "license_data": lic_data,
    }


# ----------------------------------------------------------------------
# Printing helpers (console presentation only - no logic)
# ----------------------------------------------------------------------
def _print_response(title: str, response: Dict[str, Any]) -> None:
    status = "OK" if response.get("success") else "FAIL"
    print(f"[{status}] {title}")
    for warning in response.get("warnings") or []:
        print(f"  warning: {warning}")
    if response.get("error"):
        print(f"  error: {response['error']}")


def _print_pipeline_summary(response: Dict[str, Any]) -> None:
    data = response.get("data") or {}
    print("\nPipeline summary")
    print("----------------")
    for stage in data.get("stages") or []:
        mark = {
            "completed": "[ok]", "skipped": "[--]", "warning": "[! ]",
            "failed": "[XX]", "cancelled": "[C ]",
        }.get(stage.get("status"), "[??]")
        print(f"  {mark} {stage.get('stage'):<16} ({stage.get('status')})")
    output = data.get("output_file_path")
    if output:
        print(f"\nOutput: {output}")


# ----------------------------------------------------------------------
# Subcommands
# ----------------------------------------------------------------------
def cmd_render(args: argparse.Namespace, ctx: Dict[str, Any]) -> int:
    engine: CoreEngine = ctx["engine"]
    script = Path(str(args.script))
    if not script.exists():
        print(f"[FAIL] script not found: {script}")
        return EXIT_FAIL
    project_folder = args.project_folder or str(
        find_project_root() / "projects" / script.stem
    )
    print(f"[boot] rendering script: {script}")
    response = engine.run_script_pipeline(
        script_path=str(script),
        project_folder=project_folder,
        title=args.title,
        images_folder=args.images,
        export_preset=args.preset,
        channel_profile_id=args.profile,
        skip_stages=tuple(args.skip_stage or ()),
        enforce_license=not args.skip_license,
        quality_gate=bool(args.quality_gate),
    )
    _print_response("script pipeline", response)
    _print_pipeline_summary(response)
    return EXIT_OK if response.get("success") else EXIT_FAIL


def cmd_render_project(args: argparse.Namespace, ctx: Dict[str, Any]) -> int:
    engine: CoreEngine = ctx["engine"]
    print(f"[boot] rendering project: {args.project_id}")
    response = engine.run_project_pipeline(
        str(args.project_id),
        export_preset=args.preset,
        skip_stages=tuple(args.skip_stage or ()),
        enforce_license=not args.skip_license,
        quality_gate=bool(args.quality_gate),
    )
    _print_response("project pipeline", response)
    _print_pipeline_summary(response)
    return EXIT_OK if response.get("success") else EXIT_FAIL


def cmd_check(args: argparse.Namespace, ctx: Dict[str, Any]) -> int:
    engine: CoreEngine = ctx["engine"]
    checker = engine.module("quality_checker")
    if checker is None:
        print("[FAIL] quality_checker module not loaded")
        return EXIT_FAIL
    result = checker.run_full_check(str(args.project_id))
    if not result.get("success"):
        _print_response("quality check", result)
        return EXIT_FAIL
    report = checker.generate_report(result.get("data") or {})
    print(report or "(no report text)")
    data = result.get("data") or {}
    return EXIT_OK if data.get("is_render_ready") else EXIT_FAIL


def cmd_batch(args: argparse.Namespace, ctx: Dict[str, Any]) -> int:
    engine: CoreEngine = ctx["engine"]
    batch = engine.module("batch_engine")
    if batch is None:
        print("[FAIL] batch_engine module not loaded")
        return EXIT_FAIL
    print("[boot] processing batch queue...")
    response = batch.process_queue(processor=engine.make_batch_processor())
    _print_response("batch queue", response)
    data = response.get("data") or {}
    print(
        f"  processed={data.get('processed')} completed="
        f"{data.get('completed')} failed={data.get('failed')}"
    )
    if data.get("stopped_early"):
        print("  note: queue stopped early")
    failed_count = int(data.get("failed") or 0)
    stopped = bool(data.get("stopped_early"))
    if not response.get("success"):
        return EXIT_FAIL
    return EXIT_FAIL if (failed_count and stopped) else EXIT_OK


def cmd_batch_add(args: argparse.Namespace, ctx: Dict[str, Any]) -> int:
    engine: CoreEngine = ctx["engine"]
    batch = engine.module("batch_engine")
    if batch is None:
        print("[FAIL] batch_engine module not loaded")
        return EXIT_FAIL
    response = batch.add_to_queue(
        project_folder_path=args.folder,
        project_id=args.project,
        priority=int(args.priority),
        notes=args.notes or "",
    )
    _print_response("batch add", response)
    return EXIT_OK if response.get("success") else EXIT_FAIL


def cmd_modules(args: argparse.Namespace, ctx: Dict[str, Any]) -> int:
    engine: CoreEngine = ctx["engine"]
    status = engine.get_module_status()
    data = status.get("data") or {}
    print("Module status (registry order)")
    print("------------------------------")
    report = data.get("report") or {}
    for name, info in sorted(
        report.items(), key=lambda kv: int(kv[1].get("priority") or 99)
    ):
        if info.get("loaded"):
            mark = "[ok]"
        elif not info.get("enabled"):
            mark = "[--]"
        else:
            mark = "[XX]"
        req = "required" if info.get("required") else "optional"
        error = f" ({info['error']})" if info.get("error") else ""
        print(f"  {mark} {name:<24} {req}{error}")
    plugin_status = getattr(engine, "get_plugin_status", None)
    if callable(plugin_status):  # D.8 plugin section (optional engine)
        pdata = (plugin_status() or {}).get("data") or {}
        preport = pdata.get("report") or {}
        if preport:
            print("Plugin status (alphabetical)")
            print("------------------------------")
            for name, info in sorted(preport.items()):
                if info.get("loaded"):
                    mark = "[ok]"
                elif not info.get("enabled"):
                    mark = "[--]"
                else:
                    mark = "[XX]"
                error = f" ({info['error']})" if info.get("error") else ""
                print(f"  {mark} {name:<24} plugin{error}")
    return EXIT_OK


def cmd_license(args: argparse.Namespace, ctx: Dict[str, Any]) -> int:
    license_manager: LicenseManager = ctx["license"]
    if args.activate:
        response = license_manager.activate_license(str(args.activate))
        _print_response("license activation", response)
        if not response.get("success"):
            return EXIT_FAIL
    status = (license_manager.check_license().get("data") or {})
    print("License status")
    print("--------------")
    print(f"  status:         {status.get('status')}")
    print(f"  days remaining: {status.get('days_remaining')}")
    print(f"  clock tampered: {status.get('clock_tampered')}")
    print(f"  HWID:           {(ctx['license_data'] or {}).get('hwid')}")
    ok = status.get("status") in ("active", "trial")
    return EXIT_OK if ok else EXIT_FAIL


def cmd_plugin(args: argparse.Namespace, ctx: Dict[str, Any]) -> int:
    """D.8: list plugins or run one: plugin <name> --arg k=v ..."""
    engine: CoreEngine = ctx["engine"]
    if getattr(args, "list", False) or not getattr(args, "name", None):
        data = (engine.get_plugin_status() or {}).get("data") or {}
        report = data.get("report") or {}
        print("Plugin status (alphabetical)")
        print("------------------------------")
        if not report:
            print("  (no plugins registered in"
                  " config/plugins_config.json)")
        for name, info in sorted(report.items()):
            if info.get("loaded"):
                mark = "[ok]"
            elif not info.get("enabled"):
                mark = "[--]"
            else:
                mark = "[XX]"
            error = f" ({info['error']})" if info.get("error") else ""
            print(f"  {mark} {name:<24} plugin{error}")
        return EXIT_OK
    context: Dict[str, Any] = {}
    for pair in getattr(args, "arg", None) or []:
        if "=" not in pair:
            print(f"[FAIL] --arg must be KEY=VALUE, got: {pair!r}")
            return EXIT_USAGE
        key, value = pair.split("=", 1)
        context[key] = value
    response = engine.run_plugin(args.name, context)
    out = response.get("data") or {}
    try:
        print(json.dumps(out, indent=2, default=str))
    except (TypeError, ValueError):
        print(out)
    if response.get("error"):
        print(f"[FAIL] {response['error']}")
    return EXIT_OK if response.get("success") else EXIT_FAIL


def cmd_ui(args: argparse.Namespace, ctx: Dict[str, Any]) -> int:
    print(f"[boot] {APP_NAME} {APP_VERSION} - launching UI...")
    try:
        from ui.app import launch  # D.4 seam (PyQt6 shell)
    except ImportError:
        print(
            "[--] UI needs PyQt6:  pip install -r requirements_ui.txt\n"
            "     CLI is ready:     python main.py render"
            " --script <file> --images <dir>"
        )
        return EXIT_OK
    return launch(ctx)


# ----------------------------------------------------------------------
# Argument parsing + dispatch
# ----------------------------------------------------------------------
def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="autopilot",
        description=(
            f"{APP_NAME} {APP_VERSION} - offline documentary video"
            " automation (script -> narrated MP4)"
        ),
    )
    parser.add_argument("--version", action="version",
                        version=f"{APP_NAME} {APP_VERSION}")
    sub = parser.add_subparsers(dest="command")

    render = sub.add_parser("render", help="render a script file to MP4")
    render.add_argument("--script", required=True, help="script file path")
    render.add_argument("--images", help="folder with scene images")
    render.add_argument("--project-folder", help="target project folder")
    render.add_argument("--title", help="override project title")
    render.add_argument("--preset", help="export preset (from config)")
    render.add_argument("--profile", help="channel profile id/name")
    render.add_argument("--quality-gate", action="store_true",
                        help="abort on unresolved critical/error checks")
    render.add_argument("--skip-license", action="store_true",
                        help="skip license enforcement (dev/testing)")
    render.add_argument("--skip-stage", action="append",
                        help="skip a pipeline stage (repeatable)")
    render.set_defaults(handler=cmd_render)

    render_p = sub.add_parser("render-project", help="render a DB project")
    render_p.add_argument("project_id")
    render_p.add_argument("--preset", help="export preset (from config)")
    render_p.add_argument("--quality-gate", action="store_true")
    render_p.add_argument("--skip-license", action="store_true")
    render_p.add_argument("--skip-stage", action="append")
    render_p.set_defaults(handler=cmd_render_project)

    check = sub.add_parser("check", help="run quality checks for a project")
    check.add_argument("project_id")
    check.set_defaults(handler=cmd_check)

    batch = sub.add_parser("batch", help="process the render queue")
    batch.set_defaults(handler=cmd_batch)

    batch_add = sub.add_parser("batch-add", help="queue a project render")
    batch_add.add_argument("--project", help="project id")
    batch_add.add_argument("--folder", help="project folder path")
    batch_add.add_argument("--priority", type=int, default=5)
    batch_add.add_argument("--notes", default="")
    batch_add.set_defaults(handler=cmd_batch_add)

    modules = sub.add_parser("modules", help="list module load status")
    modules.set_defaults(handler=cmd_modules)

    plugin = sub.add_parser("plugin", help="run a user plugin (D.8)")
    plugin.add_argument("name", nargs="?", help="plugin name to run")
    plugin.add_argument("--list", action="store_true",
                        help="list plugin load status")
    plugin.add_argument("--arg", action="append", default=[],
                        metavar="KEY=VALUE",
                        help="context pair for the plugin (repeatable)")
    plugin.set_defaults(handler=cmd_plugin)

    license_cmd = sub.add_parser("license", help="show license status")
    license_cmd.add_argument("--activate", metavar="KEY",
                             help="activate a license key")
    license_cmd.set_defaults(handler=cmd_license)

    ui = sub.add_parser("ui", help="launch the PyQt UI (Phase D.4)")
    ui.set_defaults(handler=cmd_ui)

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    """CLI entry point; returns the process exit code."""
    parser = _build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "command", None):
        parser.print_help()
        return EXIT_OK

    project_root = find_project_root()
    try:
        ctx = boot(project_root)
    except Exception as exc:  # noqa: BLE001 - boot must never traceback
        print(f"[FAIL] boot failed: {exc}")
        return EXIT_FAIL

    license_status = (ctx.get("license_data") or {}).get("status") or {}
    status_value = (
        license_status.get("status")
        if isinstance(license_status, dict)
        else license_status
    )
    print(
        f"[boot] {APP_NAME} {APP_VERSION} | root={project_root} | "
        f"license={status_value}"
    )
    handler = getattr(args, "handler", None)
    if handler is None:
        parser.print_help()
        return EXIT_OK
    try:
        return int(handler(args, ctx))
    except KeyboardInterrupt:
        print("\n[FAIL] interrupted by user")
        return EXIT_FAIL
    except Exception as exc:  # noqa: BLE001 - CLI never dumps tracebacks
        print(f"[FAIL] unexpected error: {exc}")
        return EXIT_FAIL


if __name__ == "__main__":
    sys.exit(main())
